// controller/UserController.java
package com.sharebasket.controller;

import com.sharebasket.dto.UserRequestDto;
import com.sharebasket.dto.UserResponseDto;
import com.sharebasket.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;



@CrossOrigin(origins = {"http://localhost:3000","http://localhost:8081"})
@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("/register")
    public UserResponseDto register(@RequestBody UserRequestDto dto) {
        return userService.register(dto);
    }

    @PostMapping("/login")
    public UserResponseDto login(@RequestBody UserRequestDto dto) {
        return userService.login(dto);
    }
}
