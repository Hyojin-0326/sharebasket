
export interface Tag {
  value: string;
  label: string;
  emoji: string;
}

export interface TagCategory {
  value: string;
  label: string;
  emoji: string;
  tags: Tag[];
}

export const tagCategories: TagCategory[] = [
  {
    value: 'groceries',
    label: '식료품',
    emoji: '📦',
    tags: [
      { value: 'fruits', label: '과일', emoji: '🍎' },
      { value: 'vegetables', label: '채소', emoji: '🥬' },
      { value: 'meat', label: '육류', emoji: '🥩' },
      { value: 'seafood', label: '수산물', emoji: '🐟' },
      { value: 'instant-foods', label: '즉석식품 / 라면', emoji: '🍜' },
      { value: 'canned', label: '통조림 / 저장식', emoji: '🥫' },
      { value: 'bakery', label: '빵 / 베이커리', emoji: '🍞' },
      { value: 'dairy', label: '유제품', emoji: '🧀' },
      { value: 'snacks', label: '간식 / 과자', emoji: '🍪' },
      { value: 'beverages', label: '음료 / 생수', emoji: '🥤' }
    ]
  },
  {
    value: 'daily-essentials',
    label: '생활용품',
    emoji: '🧻',
    tags: [
      { value: 'cleaning', label: '세제 / 청소용품', emoji: '🧴' },
      { value: 'tissues', label: '화장지 / 키친타올', emoji: '🧻' },
      { value: 'bathroom', label: '욕실용품', emoji: '🪒' },
      { value: 'personal-care', label: '비누 / 샴푸 / 세안', emoji: '🧼' },
      { value: 'kitchen-consumables', label: '주방소모품', emoji: '🧽' }
    ]
  },
  {
    value: 'pet-supplies',
    label: '반려동물용품',
    emoji: '🐾',
    tags: [
      { value: 'cat-food', label: '고양이 사료 / 간식', emoji: '🐱' },
      { value: 'dog-food', label: '강아지 사료 / 간식', emoji: '🐶' },
      { value: 'litter', label: '모래 / 배변용품', emoji: '🧴' },
      { value: 'pet-toys', label: '장난감 / 기타 용품', emoji: '🧸' }
    ]
  },
  {
    value: 'shared-goods',
    label: '공용잡화',
    emoji: '🛒',
    tags: [
      { value: 'bulk-beverages', label: '대용량 음료', emoji: '🧃' },
      { value: 'containers', label: '다회용기 / 도시락통', emoji: '🍽️' },
      { value: 'water-delivery', label: '생수 정기구매', emoji: '🧃' },
      { value: 'multipack', label: '묶음배송 품목', emoji: '📦' }
    ]
  },
  {
    value: 'stationery',
    label: '학용품 / 사무용품',
    emoji: '🧑‍🏫',
    tags: [
      { value: 'pens', label: '필기도구', emoji: '✏️' },
      { value: 'notebooks', label: '노트 / 종이류', emoji: '📒' },
      { value: 'office-supplies', label: '기타 문구', emoji: '🖍️' }
    ]
  },
  {
    value: 'etc',
    label: '기타',
    emoji: '🔌',
    tags: [
      { value: 'emergency', label: '비상용품', emoji: '🧯' },
      { value: 'seasonal', label: '계절 용품', emoji: '🧊' }
    ]
  }
];
