
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Users, MessageSquare } from 'lucide-react';
import { Avatar } from "@/components/ui/avatar";

const Notifications = () => {
  const navigate = useNavigate();
  
  // 공구 참여 알림
  const joinNotifications = [
    {
      id: 1,
      type: 'join',
      groupBuyTitle: '농심 신라면 30개입',
      user: '박이웃',
      time: '5분 전',
      isNew: true
    },
    {
      id: 2,
      type: 'join',
      groupBuyTitle: '삼다수 2L 24병',
      user: '최학생',
      time: '1시간 전',
      isNew: true
    }
  ];
  
  // 댓글 알림
  const commentNotifications = [
    {
      id: 1,
      type: 'comment',
      groupBuyTitle: '농심 신라면 30개입',
      user: '김학생',
      comment: '마감 시간에 모두 만나서 나눠가져요!',
      time: '30분 전',
      isNew: true
    },
    {
      id: 2,
      type: 'comment',
      groupBuyTitle: '삼다수 2L 24병',
      user: '이웃집',
      comment: '픽업 장소는 어디로 할까요?',
      time: '2시간 전',
      isNew: false
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* 헤더 */}
      <div className="bg-white sticky top-0 z-10 p-4 border-b shadow-sm">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold">알림</h1>
          <div className="w-8" />
        </div>
      </div>

      <div className="max-w-lg mx-auto p-4">
        {/* 공구 참여 알림 */}
        <Card className="mb-4">
          <CardHeader className="pb-3">
            <div className="flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-500" />
              <h3 className="font-medium">공구 참여 알림</h3>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {joinNotifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`flex items-center py-3 border-t cursor-pointer ${
                  notification.isNew ? 'bg-blue-50' : ''
                }`}
                onClick={() => navigate(`/groupbuy/${notification.id}`)}
              >
                <Avatar className="h-10 w-10 bg-blue-200 text-blue-700">
                  {notification.user.charAt(0)}
                </Avatar>
                <div className="ml-3 flex-1">
                  <div className="font-medium">{notification.user}님이 참여했습니다</div>
                  <div className="text-sm text-gray-600">{notification.groupBuyTitle}</div>
                  <div className="text-xs text-gray-500">{notification.time}</div>
                </div>
                {notification.isNew && (
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
        
        {/* 댓글 알림 */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center">
              <MessageSquare className="h-5 w-5 mr-2 text-blue-500" />
              <h3 className="font-medium">댓글 알림</h3>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {commentNotifications.map((notification) => (
              <div 
                key={notification.id} 
                className={`py-3 border-t cursor-pointer ${
                  notification.isNew ? 'bg-blue-50' : ''
                }`}
                onClick={() => navigate(`/groupbuy/${notification.id}`)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start">
                    <Avatar className="h-8 w-8 bg-blue-200 text-blue-700">
                      {notification.user.charAt(0)}
                    </Avatar>
                    <div className="ml-3">
                      <div className="font-medium">{notification.user}</div>
                      <div className="text-sm text-gray-600 mb-1">{notification.groupBuyTitle}</div>
                      <div className="text-sm">{notification.comment}</div>
                      <div className="text-xs text-gray-500 mt-1">{notification.time}</div>
                    </div>
                  </div>
                  {notification.isNew && (
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Notifications;
