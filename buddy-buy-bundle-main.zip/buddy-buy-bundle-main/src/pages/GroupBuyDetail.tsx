
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Clock, Copy, Users, MessageSquare, Star, CreditCard } from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import { Avatar } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import OrganizerProfile from '../components/groupbuy/OrganizerProfile';

const GroupBuyDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const groupBuy = {
    id: id || '1',
    title: '농심 신라면 30개입',
    description: '대량으로 구매하면 개당 가격이 더 저렴해요. 어차피 먹을 라면, 같이 사요!',
    image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=600&h=400&fit=crop',
    price: 40000,
    currentParticipants: 3,
    targetParticipants: 5,
    timeRemaining: '2일 13시간',
    pricePerPerson: 8500,
    location: '서울 관악구 신림동',
    organizer: {
      id: 1,
      name: '김공구',
      avatar: 'K',
      trustScore: 87,
      reviewCount: 23
    },
    participants: [
      { id: 1, name: '김학생', avatar: 'K' },
      { id: 2, name: '이웃집', avatar: 'L' },
      { id: 3, name: '박이웃', avatar: 'P' }
    ],
    comments: [
      { id: 1, author: '김학생', text: '마감 시간에 모두 만나서 나눠가져요!', time: '오늘 12:30' },
      { id: 2, author: '이웃집', text: '좋아요! 장소는 어디로 할까요?', time: '오늘 12:35' }
    ]
  };

  const handleJoin = () => {
    toast({
      title: "참여 신청 완료!",
      description: "공동구매에 참여하셨습니다. 마감 시간에 맞춰 픽업해주세요.",
    });
  };

  const handleCopyPayment = () => {
    navigator.clipboard.writeText('카카오페이/토스: 010-1234-5678');
    toast({
      title: "복사 완료!",
      description: "결제 정보가 클립보드에 복사되었습니다.",
    });
  };

  const handleOpenToss = () => {
    toast({
      title: "토스 결제",
      description: "토스 결제 페이지를 연동할 예정입니다.",
    });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* 상단 이미지 */}
      <div className="relative">
        <div className="w-full h-80 bg-white flex items-center justify-center overflow-hidden">
          <img 
            src={groupBuy.image} 
            alt={groupBuy.title}
            className="w-full h-full object-contain"
          />
        </div>
        <Button 
          variant="ghost" 
          className="absolute top-4 left-4 bg-white/80 backdrop-blur-sm rounded-full p-2 h-8 w-8"
          onClick={() => navigate('/')}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        
        {/* 이미지 위에 겹치는 정보 카드 */}
        <div className="absolute bottom-0 left-0 right-0 mx-4 mb-4">
          <Card className="bg-white rounded-xl shadow-lg">
            <CardContent className="p-4">
              <h1 className="text-xl font-bold text-gray-800 mb-1">{groupBuy.title}</h1>
              <p className="text-sm text-gray-500 mb-3">{groupBuy.location}</p>
              <p className="text-gray-600">{groupBuy.description}</p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div className="max-w-lg mx-auto p-4 space-y-4">
        {/* 대표자 프로필 */}
        <OrganizerProfile organizer={groupBuy.organizer} />
        
        <div className="flex items-center justify-between border-t border-b py-3">
          <div className="flex items-center text-sm text-gray-600">
            <Clock className="h-4 w-4 mr-1" />
            <span>{groupBuy.timeRemaining} 남음</span>
          </div>
          <div className="flex items-center text-sm text-gray-600">
            <Users className="h-4 w-4 mr-1" />
            <span>{groupBuy.currentParticipants}/{groupBuy.targetParticipants}명</span>
          </div>
        </div>
        
        <div className="bg-blue-50 p-3 rounded-lg">
          <div className="text-sm text-gray-600 mb-1">총 금액</div>
          <div className="text-xl font-bold text-gray-800">{groupBuy.price.toLocaleString()}원</div>
          <div className="text-sm text-blue-600 mt-1">1인당 예상 금액: {groupBuy.pricePerPerson.toLocaleString()}원</div>
        </div>
        
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-2">참여자 ({groupBuy.currentParticipants}명)</h3>
          <div className="flex -space-x-2">
            {groupBuy.participants.map((participant) => (
              <Avatar key={participant.id} className="border-2 border-white bg-blue-100 text-blue-600 h-8 w-8">
                {participant.avatar}
              </Avatar>
            ))}
          </div>
        </div>
        
        <Button
          className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 rounded transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
          onClick={handleJoin}
        >
          참여하기
        </Button>
        
        <div className="flex space-x-2">
          <Button
            variant="outline"
            className="flex-1 border-blue-200 text-blue-600"
            onClick={handleCopyPayment}
          >
            <Copy className="h-4 w-4 mr-1" />
            결제 정보 복사
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-blue-200 text-blue-600"
            onClick={handleOpenToss}
          >
            <CreditCard className="h-4 w-4 mr-1" />
            토스로 결제
          </Button>
        </div>
        
        {/* 댓글 섹션 */}
        <div className="mt-6">
          <h2 className="text-lg font-semibold mb-3">댓글</h2>
          <div className="space-y-4">
            {groupBuy.comments.map((comment) => (
              <div key={comment.id} className="bg-white border border-gray-100 p-3 rounded-lg">
                <div className="flex items-start justify-between">
                  <span className="font-medium">{comment.author}</span>
                  <span className="text-xs text-gray-500">{comment.time}</span>
                </div>
                <p className="text-sm mt-1">{comment.text}</p>
              </div>
            ))}
            
            <div className="flex space-x-2 mt-4">
              <Input 
                placeholder="댓글을 입력하세요" 
                className="border-gray-200 focus:ring-blue-500 focus:border-blue-500"
              />
              <Button 
                className="bg-blue-500 hover:bg-blue-600 text-white"
              >
                <MessageSquare className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupBuyDetail;
