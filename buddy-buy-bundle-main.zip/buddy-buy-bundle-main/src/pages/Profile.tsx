
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, ShoppingBag, LogOut } from 'lucide-react';
import { toast } from "@/hooks/use-toast";
import { Avatar } from "@/components/ui/avatar";

const Profile = () => {
  const navigate = useNavigate();
  
  // 사용자 정보
  const user = {
    name: '김학생',
    trustScore: 85,
    reviewCount: 12
  };
  
  // 참여한 공구 목록
  const joinedGroupBuys = [
    {
      id: '1',
      title: '농심 신라면 30개입',
      image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=80&h=80&fit=crop',
      date: '2025.05.20',
      status: '완료'
    },
    {
      id: '2',
      title: '삼다수 2L 24병',
      image: 'https://images.unsplash.com/photo-1564419429381-98dbcf916478?w=80&h=80&fit=crop',
      date: '2025.05.15',
      status: '진행중'
    }
  ];
  
  // 남이 나에게 작성한 후기
  const reviewsAboutMe = [
    {
      id: '1',
      author: '이웃집',
      content: '시간 약속을 잘 지켜주셨어요',
      rating: 5,
      date: '2025.05.18'
    },
    {
      id: '2',
      author: '박이웃',
      content: '친절하고 매너가 좋으세요',
      rating: 4,
      date: '2025.05.10'
    },
    {
      id: '3',
      author: '최학생',
      content: '정산도 빠르고 신뢰할 수 있는 분입니다',
      rating: 5,
      date: '2025.05.05'
    }
  ];
  
  const handleLogout = () => {
    localStorage.removeItem('user');
    toast({
      title: "로그아웃 완료",
      description: "안전하게 로그아웃되었습니다.",
    });
    navigate('/auth');
  };

  return (
    <div className="min-h-screen bg-white pb-6">
      {/* 헤더 */}
      <div className="bg-sky-50 pb-6">
        <div className="max-w-lg mx-auto p-4">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              className="p-0 mr-2"
              onClick={() => navigate('/')}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-bold text-gray-800">마이페이지</h1>
          </div>
          
          <div className="flex items-center">
            <Avatar className="h-16 w-16 border-4 border-white bg-sky-200 text-sky-700 text-xl">
              {user.name.charAt(0)}
            </Avatar>
            <div className="ml-4">
              <h2 className="text-lg font-bold">{user.name}</h2>
            </div>
          </div>
          
          <div className="flex mt-6">
            <div className="flex-1 bg-white rounded-lg p-3 mr-2 shadow-sm">
              <div className="text-sm text-gray-600 mb-1">신뢰도</div>
              <div className="flex items-baseline">
                <span className="text-xl font-bold text-sky-500">{user.trustScore}</span>
                <span className="text-sm text-gray-600 ml-1">/ 100</span>
              </div>
              <div className="mt-2 bg-gray-200 h-1.5 rounded-full overflow-hidden">
                <div className="bg-sky-400 h-full rounded-full" style={{ width: `${user.trustScore}%` }}></div>
              </div>
            </div>
            <div className="flex-1 bg-white rounded-lg p-3 ml-2 shadow-sm">
              <div className="text-sm text-gray-600 mb-1">후기</div>
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400 mr-1" fill="#FBBF24" />
                <span className="text-xl font-bold">{user.reviewCount}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* 내용 */}
      <div className="max-w-lg mx-auto p-4">
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex items-center">
              <ShoppingBag className="h-5 w-5 mr-2 text-sky-500" />
              <h3 className="font-medium">참여한 공동구매</h3>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {joinedGroupBuys.map((item) => (
              <div 
                key={item.id} 
                className="flex items-center py-3 border-t cursor-pointer"
                onClick={() => navigate(`/groupbuy/${item.id}`)}
              >
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-12 h-12 rounded object-cover"
                />
                <div className="ml-3">
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-gray-500">{item.date}</div>
                </div>
                <div className="ml-auto">
                  <span className={`text-sm px-2 py-1 rounded-full ${
                    item.status === '완료' ? 'bg-gray-100 text-gray-600' : 'bg-sky-100 text-sky-600'
                  }`}>
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
        
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex items-center">
              <Star className="h-5 w-5 mr-2 text-sky-500" />
              <h3 className="font-medium">받은 후기</h3>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            {reviewsAboutMe.map((review) => (
              <div key={review.id} className="py-3 border-t">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{review.author}</span>
                  <span className="text-xs text-gray-500">{review.date}</span>
                </div>
                <div className="flex items-center my-1">
                  {Array.from({ length: review.rating }).map((_, i) => (
                    <Star key={i} className="h-3 w-3 text-yellow-400" fill="#FBBF24" />
                  ))}
                </div>
                <p className="text-sm text-gray-600">{review.content}</p>
              </div>
            ))}
          </CardContent>
        </Card>
        
        <Button
          variant="outline"
          className="w-full border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          로그아웃
        </Button>
      </div>
    </div>
  );
};

export default Profile;
