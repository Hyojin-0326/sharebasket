
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const OnboardingSlide = ({ title, description, image, isLast, onNext, onPrev, showPrev }: {
  title: string;
  description: string;
  image: string;
  isLast?: boolean;
  onNext: () => void;
  onPrev: () => void;
  showPrev: boolean;
}) => (
  <div className="flex flex-col items-center justify-center min-h-screen bg-white p-6">
    <div className="max-w-md w-full text-center space-y-8">
      <div className="relative w-64 h-64 mx-auto mb-8">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover rounded-3xl shadow-lg"
        />
      </div>
      
      <div className="space-y-4">
        <h1 className="text-2xl font-bold text-gray-800 leading-tight">
          {title}
        </h1>
        <p className="text-lg text-gray-600 leading-relaxed">
          {description}
        </p>
      </div>
      
      <div className="flex justify-between items-center pt-8">
        <Button
          variant="ghost"
          size="icon"
          onClick={onPrev}
          className={`rounded-full transition-all duration-200 hover:scale-[1.1] active:scale-[0.95] hover:shadow-md ${!showPrev ? 'invisible' : ''}`}
        >
          <ChevronLeft className="h-6 w-6" />
        </Button>
        
        <div className="flex space-x-2">
          <div className="w-2 h-2 rounded-full bg-sky-400"></div>
          <div className="w-2 h-2 rounded-full bg-gray-300"></div>
          <div className="w-2 h-2 rounded-full bg-gray-300"></div>
        </div>
        
        {isLast ? (
          <Button 
            onClick={onNext}
            className="bg-sky-400 hover:bg-sky-500 text-white px-8 py-3 rounded-md font-semibold shadow-md transition-all duration-200 hover:scale-[1.05] active:scale-[0.95] hover:shadow-lg"
          >
            시작하기
          </Button>
        ) : (
          <Button
            variant="ghost"
            size="icon"
            onClick={onNext}
            className="rounded-full transition-all duration-200 hover:scale-[1.1] active:scale-[0.95] hover:shadow-md"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
        )}
      </div>
    </div>
  </div>
);

const Onboarding = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  const slides = [
    {
      title: "혼자 살아도 혼자가 아닌 공유 생활",
      description: "동네 이웃과 함께하면 혼자 사는 생활이 더 경제적이고 즐거워집니다.",
      image: "https://images.unsplash.com/photo-1721322800607-8c38375eef04?w=400&h=400&fit=crop"
    },
    {
      title: "생필품을 함께 구매하고 나눠 쓰세요!",
      description: "대량으로 구매하여 비용을 절감하고 배송비도 함께 부담하세요. 라면부터 청소용품까지 모두 함께 구매하면 저렴합니다.",
      image: "https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=400&h=400&fit=crop"
    },
    {
      title: "지금 바로 공동구매를 시작해보세요",
      description: "공동구매를 만들고 이웃을 초대하여 함께 구매하세요.",
      image: "https://images.unsplash.com/photo-1582562124811-c09040d0a901?w=400&h=400&fit=crop"
    }
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    } else {
      navigate('/');
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  return (
    <OnboardingSlide
      {...slides[currentSlide]}
      isLast={currentSlide === slides.length - 1}
      onNext={handleNext}
      onPrev={handlePrev}
      showPrev={currentSlide > 0}
    />
  );
};

export default Onboarding;
