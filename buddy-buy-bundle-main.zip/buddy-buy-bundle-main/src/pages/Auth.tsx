
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from 'react-router-dom';
import { toast } from "@/hooks/use-toast";

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    if (isLogin) {
      if (email && password) {
        try {
          const res = await fetch("http://localhost:8080/api/user/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password }),
          });
  
          if (!res.ok) throw new Error("로그인 실패");
  
          const user = await res.json();
          localStorage.setItem("user", JSON.stringify(user));
          toast({ title: "환영합니다!", description: "쉐어바스켓에 로그인되었습니다." });
          navigate("/");
        } catch (err) {
          toast({ title: "오류", description: "로그인 실패", variant: "destructive" });
        }
      } else {
        toast({ title: "오류", description: "모든 항목을 입력해주세요.", variant: "destructive" });
      }
    } else {
      if (email && password && name) {
        try {
          const res = await fetch("http://localhost:8080/api/user/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email, password, name }),
          });
  
          if (!res.ok) throw new Error("회원가입 실패");
  
          const user = await res.json();
          localStorage.setItem("user", JSON.stringify(user));
          toast({ title: "계정 생성 완료!", description: "쉐어바스켓 커뮤니티에 오신 것을 환영합니다." });
          navigate("/Onboarding");
        } catch (err) {
          toast({ title: "오류", description: "회원가입 실패", variant: "destructive" });
        }
      } else {
        toast({ title: "오류", description: "모든 항목을 입력해주세요.", variant: "destructive" });
      }
    }
  };
  

  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg border border-gray-100">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 bg-sky-400 rounded-full flex items-center justify-center mb-4">
            <span className="text-2xl">🧺</span>
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">
            {isLogin ? '로그인' : '회원가입'}
          </CardTitle>
          <CardDescription className="text-gray-600">
            {isLogin 
              ? '계정에 로그인하고 함께 공동구매를 시작하세요' 
              : '계정을 만들고 커뮤니티에 참여하세요'
            }
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">이름</label>
                <Input
                  type="text"
                  placeholder="실명 또는 닉네임"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="rounded-md border-gray-200 focus:ring-sky-400 focus:border-sky-400"
                />
              </div>
            )}
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">이메일</label>
              <Input
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="rounded-md border-gray-200 focus:ring-sky-400 focus:border-sky-400"
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">비밀번호</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="rounded-md border-gray-200 focus:ring-sky-400 focus:border-sky-400"
              />
            </div>
            
            <Button
              type="submit"
              className="w-full bg-sky-400 hover:bg-sky-500 text-white rounded-md py-2 font-medium shadow-md transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            >
              {isLogin ? '로그인' : '계정 만들기'}
            </Button>
          </form>
          
          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-sky-500 hover:text-sky-600 font-medium transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
            >
              {isLogin 
                ? "계정이 없으신가요? 회원가입" 
                : "이미 계정이 있으신가요? 로그인"
              }
            </button>
          </div>
          
          {isLogin && (
            <div className="mt-4 text-center">
              <button className="text-gray-500 hover:text-gray-600 text-sm transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]">
                비밀번호 찾기
              </button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
