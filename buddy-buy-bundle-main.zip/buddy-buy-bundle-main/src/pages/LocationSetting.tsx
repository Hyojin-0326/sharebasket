
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from 'react-router-dom';
import { toast } from "@/hooks/use-toast";
import { MapPin } from 'lucide-react';

const LocationSetting = () => {
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState('');
  const navigate = useNavigate();

  const cities = [
    { value: 'seoul', label: 'Seoul' },
    { value: 'busan', label: 'Busan' },
    { value: 'daegu', label: 'Daegu' },
    { value: 'incheon', label: 'Incheon' },
    { value: 'gwangju', label: 'Gwangju' },
    { value: 'daejeon', label: 'Daejeon' }
  ];

  const districts: { [key: string]: { value: string; label: string }[] } = {
    seoul: [
      { value: 'gwanak', label: 'Gwanak-gu (Sillim-dong)' },
      { value: 'gangnam', label: 'Gangnam-gu' },
      { value: 'mapo', label: 'Mapo-gu (Hongdae)' },
      { value: 'jongno', label: 'Jongno-gu' },
      { value: 'seodaemun', label: 'Seodaemun-gu' }
    ],
    busan: [
      { value: 'haeundae', label: 'Haeundae-gu' },
      { value: 'busanjin', label: 'Busanjin-gu' },
      { value: 'seo', label: 'Seo-gu' }
    ],
    daegu: [
      { value: 'suseong', label: 'Suseong-gu' },
      { value: 'jung', label: 'Jung-gu' }
    ],
    incheon: [
      { value: 'yeonsu', label: 'Yeonsu-gu' },
      { value: 'namdong', label: 'Namdong-gu' }
    ],
    gwangju: [
      { value: 'seo', label: 'Seo-gu' },
      { value: 'nam', label: 'Nam-gu' }
    ],
    daejeon: [
      { value: 'yuseong', label: 'Yuseong-gu' },
      { value: 'seo', label: 'Seo-gu' }
    ]
  };

  const handleConfirm = () => {
    if (selectedCity && selectedDistrict) {
      const cityLabel = cities.find(c => c.value === selectedCity)?.label;
      const districtLabel = districts[selectedCity]?.find(d => d.value === selectedDistrict)?.label;
      
      localStorage.setItem('userLocation', JSON.stringify({
        city: selectedCity,
        district: selectedDistrict,
        cityLabel,
        districtLabel
      }));
      
      toast({
        title: "Location set!",
        description: `You'll see group buys in ${districtLabel}, ${cityLabel}`,
      });
      
      navigate('/');
    } else {
      toast({
        title: "Please select your location",
        description: "Both city and district are required.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-mint-50 to-yellow-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-0 bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto w-16 h-16 bg-gradient-to-r from-blue-400 to-mint-400 rounded-full flex items-center justify-center mb-4">
            <MapPin className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">
            Set Your Location
          </CardTitle>
          <CardDescription className="text-gray-600">
            Choose your area to find group buys near you
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">City/Province</label>
            <Select value={selectedCity} onValueChange={setSelectedCity}>
              <SelectTrigger className="rounded-full border-gray-200 focus:ring-blue-400 focus:border-blue-400">
                <SelectValue placeholder="Select your city" />
              </SelectTrigger>
              <SelectContent>
                {cities.map((city) => (
                  <SelectItem key={city.value} value={city.value}>
                    {city.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">District/Neighborhood</label>
            <Select 
              value={selectedDistrict} 
              onValueChange={setSelectedDistrict}
              disabled={!selectedCity}
            >
              <SelectTrigger className="rounded-full border-gray-200 focus:ring-blue-400 focus:border-blue-400">
                <SelectValue placeholder="Select your district" />
              </SelectTrigger>
              <SelectContent>
                {selectedCity && districts[selectedCity]?.map((district) => (
                  <SelectItem key={district.value} value={district.value}>
                    {district.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <Button
            onClick={handleConfirm}
            disabled={!selectedCity || !selectedDistrict}
            className="w-full bg-gradient-to-r from-blue-400 to-mint-400 hover:from-blue-500 hover:to-mint-500 text-white rounded-full py-3 font-semibold shadow-lg transition-all duration-200 hover:scale-105 active:scale-95 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
          >
            Confirm and Go to Home
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default LocationSetting;
