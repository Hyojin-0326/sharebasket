import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Users, Clock, User, Bell } from 'lucide-react';
import { tagCategories } from '@/data/tagData';
import { useAuth } from '@/context/AuthContext';

const Home = () => {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('deadline');
  const [searchTerm, setSearchTerm] = useState('');
  const hasNewNotifications = true;

  useEffect(() => {
    if (!isLoading&&!user) {
      navigate('/auth');
    }
  }, [user]);
  if(isLoading) return null;
  if (!user) return null;


  const groupBuys = [
    {
      id: '1',
      title: '농심 신라면 30개입',
      description: '대량으로 구매하면 개당 가격이 더 저렴해요. 어차피 먹을 라면, 같이 사요!',
      image: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?w=200&h=200&fit=crop',
      price: 40000,
      currentParticipants: 3,
      targetParticipants: 5,
      timeRemaining: '2일 13시간',
      pricePerPerson: 8500,
      location: '서울 관악구 신림동',
      category: 'groceries'
    },
    {
      id: '2',
      title: '삼다수 2L 24병',
      description: '무거운 물, 이제 집 앞에서 편하게 받으세요!',
      image: 'https://images.unsplash.com/photo-1564419429381-98dbcf916478?w=200&h=200&fit=crop',
      price: 25000,
      currentParticipants: 8,
      targetParticipants: 10,
      timeRemaining: '1일 5시간',
      pricePerPerson: 2800,
      location: '서울 관악구 봉천동',
      category: 'beverages'
    },
    {
      id: '3',
      title: '깨끗한나라 화장지 30롤',
      description: '화장지, 쟁여두면 맘이 편안하죠.',
      image: 'https://images.unsplash.com/photo-1622541863325-8b7994419401?w=200&h=200&fit=crop',
      price: 32000,
      currentParticipants: 4,
      targetParticipants: 8,
      timeRemaining: '3일 2시간',
      pricePerPerson: 8000,
      location: '경기 성남시 분당구',
      category: 'tissues'
    },
    {
      id: '4',
      title: '하기스 아기 물티슈 10팩',
      description: '육아 필수템, 저렴하게 공동구매!',
      image: 'https://images.unsplash.com/photo-1623428454976-9441f5459539?w=200&h=200&fit=crop',
      price: 28000,
      currentParticipants: 6,
      targetParticipants: 12,
      timeRemaining: '2일 8시간',
      pricePerPerson: 4700,
      location: '서울 강남구 역삼동',
      category: 'personal-care'
    },
    {
      id: '5',
      title: 'LG생활건강 세탁세제',
      description: '세탁세제, 향이 너무 좋아요!',
      image: 'https://plus.unsplash.com/premium_photo-1661962447969-94b5393648c9?w=200&h=200&fit=crop',
      price: 21000,
      currentParticipants: 5,
      targetParticipants: 10,
      timeRemaining: '1일 10시간',
      pricePerPerson: 4200,
      location: '서울 서초구 반포동',
      category: 'cleaning'
    }
  ];

  const filteredGroupBuys = selectedCategory === 'all'
    ? groupBuys
    : groupBuys.filter(groupBuy => {
        const category = tagCategories.find(cat => cat.value === groupBuy.category);
        return category?.tags.some(tag => tag.value === selectedCategory) || groupBuy.category === selectedCategory;
      });

  const searchedGroupBuys = filteredGroupBuys.filter(groupBuy =>
    groupBuy.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredAndSortedGroupBuys = [...searchedGroupBuys].sort((a, b) => {
    if (sortBy === 'deadline') {
      const getTimeRemainingInHours = (timeRemaining: string) => {
        const [days, hours] = timeRemaining.split('일 ');
        return parseInt(days) * 24 + parseInt(hours.replace('시간', ''));
      };
      return getTimeRemainingInHours(a.timeRemaining) - getTimeRemainingInHours(b.timeRemaining);
    } else if (sortBy === 'participants') {
      return b.currentParticipants - a.currentParticipants;
    } else {
      return 0;
    }
  });

  return (
    <div className="min-h-screen bg-white pb-20">
      {/* 헤더 */}
      <div className="bg-white sticky top-0 z-10 p-4 border-b shadow-sm">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <h1 className="text-xl font-bold text-gray-800">공동구매</h1>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="relative" onClick={() => navigate('/notifications')}>
              <Bell className="h-5 w-5" />
              {hasNewNotifications && (
                <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#3B82F6] rounded-full"></div>
              )}
            </Button>
            <Button variant="ghost" size="icon" onClick={() => navigate('/profile')}>
              <User className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-lg mx-auto p-4">
        {/* 검색 */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          <Input
            placeholder="상품명으로 검색"
            className="pl-10 border-gray-200 focus:ring-[#3B82F6] focus:border-[#3B82F6]"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {/* 필터 및 정렬 */}
        <div className="flex space-x-2 mb-4">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="카테고리 선택" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">전체</SelectItem>
              <SelectItem value="groceries">📦 식료품</SelectItem>
              <SelectItem value="daily-essentials">🧻 생활용품</SelectItem>
              <SelectItem value="pet-supplies">🐾 반려동물용품</SelectItem>
              <SelectItem value="shared-goods">🛒 공용잡화</SelectItem>
              <SelectItem value="stationery">🧑‍🏫 학용품/사무용품</SelectItem>
              <SelectItem value="etc">🔌 기타</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="flex-1">
              <SelectValue placeholder="정렬" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="deadline">마감 임박순</SelectItem>
              <SelectItem value="participants">인원 많은 순</SelectItem>
              <SelectItem value="latest">최신순</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* 공구 리스트 */}
        <div className="space-y-4">
          {filteredAndSortedGroupBuys.map((groupBuy) => (
            <Card
              key={groupBuy.id}
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => navigate(`/groupbuy/${groupBuy.id}`)}
            >
              <CardContent className="p-4">
                <div className="flex">
                  <img
                    src={groupBuy.image}
                    alt={groupBuy.title}
                    className="w-20 h-20 rounded-lg object-cover"
                  />
                  <div className="ml-4 flex-1">
                    <h3 className="font-semibold text-gray-800 mb-1">{groupBuy.title}</h3>
                    <p className="text-sm text-gray-600 mb-2">{groupBuy.location}</p>

                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center text-gray-600">
                        <Users className="h-4 w-4 mr-1" />
                        <span>{groupBuy.currentParticipants}/{groupBuy.targetParticipants}명</span>
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>{groupBuy.timeRemaining}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <div className="text-[#2563EB] font-semibold">
                        {groupBuy.pricePerPerson.toLocaleString()}원/인
                      </div>
                      <Button
                        size="sm"
                        className="bg-[#3B82F6] hover:bg-[#2563EB] text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          // 참여하기 로직 넣을 곳
                        }}
                      >
                        참여하기
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* 플로팅 버튼 */}
      <Button
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-[#3B82F6] hover:bg-[#2563EB] shadow-lg text-white"
        onClick={() => navigate('/create')}
      >
        <Plus className="h-6 w-6" />
      </Button>
    </div>
  );
};

export default Home;
