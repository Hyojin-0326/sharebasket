
import React from 'react';
import { Button } from "@/components/ui/button";
import { useNavigate } from 'react-router-dom';

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <div className="text-center space-y-8 p-6">
        <div className="space-y-4">
          <div className="mx-auto w-24 h-24 bg-sky-400 rounded-full flex items-center justify-center mb-6 shadow-xl">
            <span className="text-4xl">🧺</span>
          </div>
          <h1 className="text-5xl font-bold mb-4 text-sky-500">
            쉐어바스켓
          </h1>
          <p className="text-xl text-gray-600 max-w-md mx-auto leading-relaxed">
            친구들과 함께 생필품을 구매하고 비용을 절약하세요!
          </p>
        </div>
        
        <div className="space-y-4">
          <Button 
            onClick={() => navigate('/onboarding')}
            className="bg-sky-400 hover:bg-sky-500 text-white px-8 py-4 rounded-md font-semibold shadow-lg text-lg transition-all duration-200 hover:scale-[1.05] active:scale-[0.95]"
            size="lg"
          >
            시작하기
          </Button>
          
          <div>
            <Button 
              onClick={() => navigate('/auth')}
              variant="ghost"
              className="text-gray-600 hover:text-gray-800 underline transition-all duration-200 hover:scale-[1.05] active:scale-[0.95]"
            >
              이미 계정이 있으신가요? 로그인
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
