
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Upload, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { tagCategories } from '@/data/tagData';

const CreateGroupBuy = () => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedTag, setSelectedTag] = useState<string>('');
  const [imageUrl, setImageUrl] = useState('');

  const handleImageUpload = async (file: File) => {
    const formData = new FormData();
    formData.append("file", file);
  
    const res = await fetch("http://localhost:8080/api/upload", {
      method: "POST",
      body: formData,
    });
  
    const data = await res.text(); // ex: "/images/filename.png"
    return data;
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      console.log("📂 선택된 파일:", file.name);
      const uploadedUrl = await handleImageUpload(file);
      console.log("🌐 업로드된 이미지 URL:", uploadedUrl);
      setImageUrl(uploadedUrl);
    } else {
      console.warn("파일이 선택되지 않음");
    }
  };
  
  

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
  
    const title = (document.getElementById('productName') as HTMLInputElement).value;
    const description = (document.getElementById('description') as HTMLTextAreaElement).value;
    const maxParticipants = Number((document.getElementById('targetParticipants') as HTMLInputElement).value);
    const pricePerPerson = Math.floor(Number((document.getElementById('totalPrice') as HTMLInputElement).value) / maxParticipants);
    const location = "서울시 관악구"; // 예시
    const deadline = (document.getElementById('deadline') as HTMLInputElement).value;
  
    try {
      const res = await fetch("http://localhost:8080/api/groupbuy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          location,
          maxParticipants,
          pricePerPerson,
          deadline,
          imageUrl
        }),
      });
  
      if (!res.ok) throw new Error("공구 등록 실패");
  
      // 성공 시 홈으로 이동
      navigate("/");
    } catch (err) {
      console.error(err);
      alert("공동구매 등록 중 오류 발생");
    }
  };
  

  const getSelectedCategoryTags = () => {
    if (!selectedCategory) return [];
    const category = tagCategories.find(cat => cat.value === selectedCategory);
    return category ? category.tags : [];
  };

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-white sticky top-0 z-10 p-4 border-b shadow-sm">
        <div className="flex items-center justify-between max-w-lg mx-auto">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => navigate('/')}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-semibold">공구 만들기</h1>
          <div className="w-8" />
        </div>
      </div>

      <div className="max-w-lg mx-auto p-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-[#a5cbf0]" />
              지역 설정
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="시/도 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="seoul">서울특별시</SelectItem>
                    <SelectItem value="busan">부산광역시</SelectItem>
                    <SelectItem value="incheon">인천광역시</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="구/동 선택" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="gangnam">강남구</SelectItem>
                    <SelectItem value="gwanak">관악구</SelectItem>
                    <SelectItem value="mapo">마포구</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-4">
          <CardHeader>
            <CardTitle>상품 정보</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="productName">상품명</Label>
                <Input id="productName" placeholder="예: 농심 신라면 30개입" required />
              </div>

              <div>
                <Label htmlFor="productImage">상품 사진</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600">사진을 업로드하세요</p>
                  <Input type="file" className="hidden" id="productImage" accept="image/*" onChange={handleFileChange}/>
                  <Button variant="outline" className="mt-2" onClick={() => document.getElementById('productImage')?.click()}>
                    파일 선택
                  </Button>
                </div>
              </div>


              <div>
                <Label htmlFor="description">상품 설명 (선택)</Label>
                <Textarea 
                  id="description" 
                  placeholder="상품에 대한 간단한 설명을 입력하세요"
                  className="min-h-[80px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="quantity">수량</Label>
                  <Input id="quantity" type="number" placeholder="30" required />
                </div>
                <div>
                  <Label htmlFor="totalPrice">총 가격 (원)</Label>
                  <Input id="totalPrice" type="number" placeholder="40000" required />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="targetParticipants">목표 인원</Label>
                  <Input id="targetParticipants" type="number" placeholder="5" required />
                </div>
                <div>
                  <Label htmlFor="deadline">마감 시간</Label>
                  <Input id="deadline" type="datetime-local" required />
                </div>
              </div>

              <div className="space-y-2">
                <Label>카테고리 및 태그</Label>
                <div className="grid grid-cols-2 gap-2">
                  <Select value={selectedCategory} onValueChange={(value) => {
                    setSelectedCategory(value);
                    setSelectedTag('');
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="카테고리 선택" />
                    </SelectTrigger>
                    <SelectContent>
                      {tagCategories.map((category) => (
                        <SelectItem key={category.value} value={category.value}>
                          <span className="flex items-center gap-2">
                            <span>{category.emoji}</span>
                            <span>{category.label}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select value={selectedTag} onValueChange={setSelectedTag} disabled={!selectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="세부 태그" />
                    </SelectTrigger>
                    <SelectContent>
                      {getSelectedCategoryTags().map((tag) => (
                        <SelectItem key={tag.value} value={tag.value}>
                          <span className="flex items-center gap-2">
                            <span>{tag.emoji}</span>
                            <span>{tag.label}</span>
                          </span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-[#a5cbf0] hover:bg-[#a5cbf0]/90 text-white py-3 transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
              >
                공구 만들기
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CreateGroupBuy;
