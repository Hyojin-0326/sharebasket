
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Avatar } from "@/components/ui/avatar";
import { Star } from 'lucide-react';

interface Organizer {
  id: number;
  name: string;
  avatar: string;
  trustScore: number;
  reviewCount: number;
}

interface OrganizerProfileModalProps {
  organizer: Organizer;
  isOpen: boolean;
  onClose: () => void;
}

const OrganizerProfileModal = ({ organizer, isOpen, onClose }: OrganizerProfileModalProps) => {
  const recentReviews = [
    {
      id: 1,
      author: '김학생',
      content: '시간 약속을 잘 지켜주셨어요',
      rating: 5,
      date: '2025.05.18'
    },
    {
      id: 2,
      author: '이웃집',
      content: '친절하고 매너가 좋으세요',
      rating: 4,
      date: '2025.05.10'
    },
    {
      id: 3,
      author: '박이웃',
      content: '정산도 빠르고 신뢰할 수 있는 분입니다',
      rating: 5,
      date: '2025.05.05'
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto">
        <DialogHeader>
          <DialogTitle className="text-center">프로필</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* 프로필 정보 */}
          <div className="flex flex-col items-center">
            <Avatar className="h-20 w-20 bg-blue-200 text-blue-700 text-2xl font-semibold mb-3">
              {organizer.avatar}
            </Avatar>
            <h3 className="text-lg font-semibold">{organizer.name}</h3>
          </div>
          
          {/* 신뢰도 점수 */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-sm text-gray-600 mb-2">신뢰도</div>
            <div className="flex items-baseline mb-2">
              <span className="text-2xl font-bold text-blue-500">{organizer.trustScore}</span>
              <span className="text-sm text-gray-600 ml-1">/ 100</span>
            </div>
            <div className="bg-gray-200 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-blue-400 h-full rounded-full transition-all duration-300" 
                style={{ width: `${organizer.trustScore}%` }}
              ></div>
            </div>
          </div>
          
          {/* 최근 후기 */}
          <div>
            <h4 className="font-medium mb-3">최근 후기</h4>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {recentReviews.map((review) => (
                <div key={review.id} className="border-b pb-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-sm">{review.author}</span>
                    <span className="text-xs text-gray-500">{review.date}</span>
                  </div>
                  <div className="flex items-center mb-1">
                    {Array.from({ length: review.rating }).map((_, i) => (
                      <Star key={i} className="h-3 w-3 text-yellow-400" fill="#FBBF24" />
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">{review.content}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default OrganizerProfileModal;
