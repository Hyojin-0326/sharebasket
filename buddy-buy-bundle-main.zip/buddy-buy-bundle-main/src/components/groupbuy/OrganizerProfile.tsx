
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { Star } from 'lucide-react';
import OrganizerProfileModal from './OrganizerProfileModal';

interface Organizer {
  id: number;
  name: string;
  avatar: string;
  trustScore: number;
  reviewCount: number;
}

interface OrganizerProfileProps {
  organizer: Organizer;
}

const OrganizerProfile = ({ organizer }: OrganizerProfileProps) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className="bg-white p-3 rounded-lg border border-gray-100">
        <h3 className="text-sm font-medium text-gray-700 mb-2">공구 대표자</h3>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar className="bg-blue-200 text-blue-700 h-10 w-10 flex items-center justify-center text-lg font-semibold">
              {organizer.avatar}
            </Avatar>
            <div>
              <div className="font-medium">{organizer.name}</div>
              <div className="flex items-center text-sm text-gray-600">
                <Star className="h-3 w-3 mr-1 text-yellow-400 fill-current" />
                <span>신뢰도 {organizer.trustScore}% · 후기 {organizer.reviewCount}개</span>
              </div>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm"
            className="border-blue-300 text-blue-600 hover:bg-blue-50"
            onClick={() => setIsModalOpen(true)}
          >
            프로필 보기
          </Button>
        </div>
      </div>
      
      <OrganizerProfileModal 
        organizer={organizer}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
};

export default OrganizerProfile;
